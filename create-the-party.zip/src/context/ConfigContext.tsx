import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { PRODUCTS as INITIAL_PRODUCTS } from '../constants';

interface SiteSection {
  id: string;
  title: string;
  content: string;
  icon: string;
}

interface ContactLink {
  id: string;
  label: string;
  value: string;
  url: string;
  icon: 'phone' | 'map-pin' | 'instagram' | 'facebook' | 'message-circle' | 'mail';
}

interface SiteConfig {
  name: string;
  description: string;
  logoText: string;
  primaryColor: string;
  fontFamily: string;
  heroTitle: string;
  heroSubtitle: string;
  contactPhone: string;
  contactAddress: string;
  products: Product[];
  sections: SiteSection[];
  contactLinks: ContactLink[];
}

const DEFAULT_CONFIG: SiteConfig = {
  name: 'Create The Party',
  description: 'Premium 3D animated e-commerce platform for balloon bouquets, decoration packages, and gift hampers.',
  logoText: 'P',
  primaryColor: '#EC4899', // pink-500
  fontFamily: 'Outfit',
  heroTitle: 'Create The Perfect Party',
  heroSubtitle: 'Premium balloon bouquets, luxury decoration packages, and curated gift hampers for every occasion.',
  contactPhone: '+91 80804 15406',
  contactAddress: 'Aundh-Wakad Rd, Vishal Nagar, Pimple Nilakh, Pune, Pimpri-Chinchwad, Maharashtra 411027, India',
  products: INITIAL_PRODUCTS,
  sections: [
    { id: '1', title: 'Quality Balloons', content: 'We use only premium biodegradable latex balloons for all our setups.', icon: '🎈' },
    { id: '2', title: 'Expert Design', content: 'Our team of certified balloon artists ensures your party looks like a dream.', icon: '🎨' },
    { id: '3', title: 'Same Day Delivery', content: 'Need a surprise last minute? We offer quick turnaround for local orders.', icon: '🚚' }
  ],
  contactLinks: [
    { id: '1', label: 'Phone', value: '+91 80804 15406', url: 'tel:+918080415406', icon: 'phone' },
    { id: '2', label: 'Address', value: 'Vishal Nagar, Pimple Nilakh, Pune', url: 'https://maps.google.com', icon: 'map-pin' },
    { id: '3', label: 'Instagram', value: '@createtheparty', url: 'https://instagram.com', icon: 'instagram' },
    { id: '4', label: 'WhatsApp', value: 'Message us', url: 'https://wa.me/918080415406', icon: 'message-circle' }
  ]
};

interface ConfigContextType {
  config: SiteConfig;
  updateConfig: (newConfig: Partial<SiteConfig>) => void;
  resetConfig: () => void;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

export function ConfigProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('site-config');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Merge with default to ensure new properties like 'sections' exist
      return { ...DEFAULT_CONFIG, ...parsed };
    }
    return DEFAULT_CONFIG;
  });

  useEffect(() => {
    localStorage.setItem('site-config', JSON.stringify(config));
  }, [config]);

  const updateConfig = (newConfig: Partial<SiteConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  const resetConfig = () => {
    setConfig(DEFAULT_CONFIG);
  };

  return (
    <ConfigContext.Provider value={{ config, updateConfig, resetConfig }}>
      <div style={{ '--primary-color': config.primaryColor, '--font-display': config.fontFamily } as React.CSSProperties}>
        {children}
      </div>
    </ConfigContext.Provider>
  );
}

export function useConfig() {
  const context = useContext(ConfigContext);
  if (!context) {
    throw new Error('useConfig must be used within a ConfigProvider');
  }
  return context;
}
