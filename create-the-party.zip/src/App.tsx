/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import ThreeScene from './components/ThreeScene';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import BookingModal from './components/BookingModal';
import Admin from './pages/Admin';
import { useConfig } from './context/ConfigContext';
import { Product } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Phone, Instagram, MapPin, Facebook, Mail, MessageCircle } from 'lucide-react';

function Header() {
  const { config } = useConfig();
  return (
    <div className="py-20 text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="inline-block px-4 py-1.5 bg-pink-100 text-pink-600 rounded-full text-sm font-bold mb-6"
        style={{ color: config.primaryColor, backgroundColor: `${config.primaryColor}20` }}
      >
        ✨ Making your celebrations unforgettable
      </motion.div>
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-6xl md:text-8xl font-display font-black tracking-tight text-slate-900 mb-8"
      >
        {config.heroTitle.split(' ').length > 2 ? (
          <>
            {config.heroTitle.split(' ').slice(0, -2).join(' ')} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r" style={{ backgroundImage: `linear-gradient(to right, ${config.primaryColor}, #8B5CF6, #3B82F6)` }}>
              {config.heroTitle.split(' ').slice(-2).join(' ')}
            </span>
          </>
        ) : (
          <span className="text-transparent bg-clip-text bg-gradient-to-r" style={{ backgroundImage: `linear-gradient(to right, ${config.primaryColor}, #8B5CF6, #3B82F6)` }}>
            {config.heroTitle}
          </span>
        )}
      </motion.h1>
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="max-w-2xl mx-auto text-xl text-slate-600 mb-12"
      >
        {config.heroSubtitle}
      </motion.p>
    </div>
  );
}

function Home() {
  const { config } = useConfig();
  const [activePage, setActivePage] = useState('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = activePage === 'home' 
    ? config.products 
    : config.products.filter(p => p.category === activePage.slice(0, -1) || p.category === activePage);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activePage]);

  return (
    <div className="relative min-h-screen">
      <ThreeScene />
      <Navbar activePage={activePage} onNavigate={setActivePage} />

      <main className="pt-24 pb-20">
        <AnimatePresence mode="wait">
          {activePage === 'home' ? (
            <motion.section
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-7xl mx-auto px-4"
            >
              <Header />
              
              <motion.div
                 initial={{ y: 20, opacity: 0 }}
                 animate={{ y: 0, opacity: 1 }}
                 transition={{ delay: 0.5 }}
                 className="flex flex-wrap justify-center gap-4 mb-20"
              >
                <button 
                  onClick={() => setActivePage('bouquets')}
                  className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-pink-600 transition-all flex items-center gap-2 group"
                  style={{ backgroundColor: config.primaryColor }}
                >
                  Explore Catalog
                  <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="bg-white text-slate-700 px-8 py-4 rounded-2xl font-bold text-lg shadow-lg border border-slate-100 hover:bg-slate-50 transition-all">
                  View Gallery
                </button>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 py-20">
                {[
                  { id: 'bouquets', name: 'Balloon Bouquets', icon: '🎈', color: 'from-pink-400 to-rose-500' },
                  { id: 'packages', name: 'Decoration Packages', icon: '🎉', color: 'from-purple-400 to-indigo-500' },
                  { id: 'hampers', name: 'Gift Hampers', icon: '🎁', color: 'from-blue-400 to-cyan-500' },
                  { id: 'combos', name: 'Best Combos', icon: '🔥', color: 'from-orange-400 to-red-500' },
                ].map((cat, i) => (
                  <motion.div
                    key={cat.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    viewport={{ once: true }}
                    onClick={() => setActivePage(cat.id)}
                    className="group cursor-pointer"
                  >
                    <div className={`h-40 rounded-[32px] bg-gradient-to-br ${cat.color} p-8 flex flex-col justify-end text-white shadow-lg relative overflow-hidden`}>
                      <span className="text-4xl absolute top-4 right-4 group-hover:scale-125 transition-transform">{cat.icon}</span>
                      <h3 className="text-xl font-bold">{cat.name}</h3>
                      <p className="text-white/80 text-sm">Shop Now</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="space-y-12">
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-4xl font-display font-black text-slate-900">Popular Choices</h2>
                    <p className="text-slate-500">Trending items our customers love</p>
                  </div>
                  <button 
                    onClick={() => setActivePage('bouquets')}
                    className="font-bold flex items-center gap-1 hover:gap-2 transition-all"
                    style={{ color: config.primaryColor }}
                  >
                    View All <ChevronRight size={18} />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {config.products.slice(0, 3).map(product => (
                    <ProductCard 
                      key={product.id} 
                      product={product} 
                      onSelect={setSelectedProduct} 
                    />
                  ))}
                </div>
              </div>

              {/* Custom Sections */}
              {(config.sections || []).length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-20 border-t border-slate-100 mt-20">
                  {config.sections.map((section) => (
                    <motion.div
                      key={section.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      className="p-8 bg-white/40 backdrop-blur-sm rounded-3xl border border-white/30 shadow-lg text-center"
                    >
                      <div className="text-5xl mb-6">{section.icon}</div>
                      <h3 className="text-2xl font-display font-bold text-slate-900 mb-4">{section.title}</h3>
                      <p className="text-slate-600 leading-relaxed">{section.content}</p>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.section>
          ) : (
            <motion.section
              key={activePage}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-7xl mx-auto px-4"
            >
              <div className="mb-12">
                <h1 className="text-5xl font-display font-black text-slate-900 capitalize mb-4">
                  {activePage}
                </h1>
                <p className="text-slate-500 max-w-xl">
                  Handcrafted {activePage} designed to bring joy and color to your most precious moments.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map(product => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    onSelect={setSelectedProduct} 
                  />
                ))}
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>

      <footer className="bg-slate-950 text-white py-20 mt-20">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
           <div className="space-y-6 col-span-1 md:col-span-2">
              <div className="flex items-center gap-2">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg"
                  style={{ backgroundColor: config.primaryColor }}
                >
                  {config.logoText}
                </div>
                <span className="font-display font-bold text-2xl tracking-tighter">{config.name}</span>
              </div>
              <p className="text-slate-400 max-w-sm">
                India's premium party planners and balloon artists. We transform spaces into magical experiences.
              </p>
              <div className="flex gap-4">
                 {(config.contactLinks || []).filter(l => ['instagram', 'facebook', 'message-circle', 'mail'].includes(l.icon)).map(link => {
                    const Icon = ({
                      instagram: Instagram,
                      facebook: Facebook,
                      'message-circle': MessageCircle,
                      mail: Mail
                    } as any)[link.icon] || MessageCircle;

                    return (
                      <a 
                        key={link.id}
                        href={link.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-all text-slate-400 group"
                      >
                         <Icon size={24} className="group-hover:scale-110 transition-transform" style={{ color: link.icon === 'message-circle' ? '#22c55e' : config.primaryColor }} />
                      </a>
                    );
                 })}
              </div>
           </div>

           <div className="space-y-6">
              <h3 className="font-bold text-lg uppercase tracking-widest text-slate-500">Category</h3>
              <ul className="space-y-4">
                <li><button onClick={() => setActivePage('bouquets')} className="text-slate-300 hover:text-white transition-colors">Balloon Bouquets</button></li>
                <li><button onClick={() => setActivePage('packages')} className="text-slate-300 hover:text-white transition-colors">Decoration Packages</button></li>
                <li><button onClick={() => setActivePage('hampers')} className="text-slate-300 hover:text-white transition-colors">Gift Hampers</button></li>
                <li><button onClick={() => setActivePage('combos')} className="text-slate-300 hover:text-white transition-colors">Exclusive Combos</button></li>
              </ul>
           </div>

           <div className="space-y-6">
              <h3 className="font-bold text-lg uppercase tracking-widest text-slate-500">Contact</h3>
              <ul className="space-y-4 text-slate-300">
                <li className="flex items-start gap-3">
                  <Phone size={18} style={{ color: config.primaryColor }} className="mt-1 shrink-0" />
                  <div>
                    <p className="font-bold text-[10px] uppercase text-slate-500 tracking-wider">Call Us</p>
                    <p>{config.contactPhone}</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin size={18} style={{ color: config.primaryColor }} className="mt-1 shrink-0" />
                  <div>
                    <p className="font-bold text-[10px] uppercase text-slate-500 tracking-wider">Visit Us</p>
                    <p className="text-sm">{config.contactAddress}</p>
                  </div>
                </li>
                
                {/* Dynamic Links */}
                {(config.contactLinks || []).filter(l => !['phone', 'map-pin'].includes(l.icon)).map((link) => {
                  const Icon = ({
                    phone: Phone,
                    'map-pin': MapPin,
                    instagram: Instagram,
                    facebook: Facebook,
                    'message-circle': MessageCircle,
                    mail: Mail
                  } as any)[link.icon] || MessageCircle;

                  return (
                    <li key={link.id} className="flex items-start gap-3 group">
                      <a 
                        href={link.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-start gap-3 hover:text-white transition-colors"
                      >
                        <Icon size={18} style={{ color: config.primaryColor }} className="mt-1 shrink-0 group-hover:scale-110 transition-transform" />
                        <div className="text-sm">
                          <p className="font-bold text-[10px] uppercase text-slate-500 tracking-wider mb-0.5">{link.label}</p>
                          <p>{link.value}</p>
                        </div>
                      </a>
                    </li>
                  );
                })}
              </ul>
           </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 pt-12 mt-12 border-t border-white/5 text-center text-slate-500 text-sm">
          © {new Date().getFullYear()} {config.name}. All Rights Reserved.
        </div>
      </footer>

      <AnimatePresence>
        {selectedProduct && (
          <BookingModal 
            product={selectedProduct} 
            onClose={() => setSelectedProduct(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  const location = useLocation();

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/admin" element={<Admin />} />
    </Routes>
  );
}
