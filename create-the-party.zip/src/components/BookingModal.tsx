import React from 'react';
import { motion } from 'motion/react';
import { X, Calendar, Clock, User, Phone, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { useConfig } from '../context/ConfigContext';
import confetti from 'canvas-confetti';

interface BookingModalProps {
  product: Product;
  onClose: () => void;
}

export default function BookingModal({ product, onClose }: BookingModalProps) {
  const { config } = useConfig();
  const [step, setStep] = React.useState(1);
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate booking
    setTimeout(() => {
      setLoading(false);
      setStep(3);
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: [config.primaryColor, '#8B5CF6', '#3B82F6']
      });
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
      />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative w-full max-w-lg bg-white rounded-[32px] shadow-2xl overflow-hidden"
      >
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors z-10"
        >
          <X size={20} />
        </button>

        <div className="p-8">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div 
                  className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{ backgroundColor: `${config.primaryColor}20`, color: config.primaryColor }}
                >
                  <Sparkles size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">Customize & Book</h2>
                  <p className="text-slate-500">{product.name}</p>
                </div>
              </div>

              <div className="space-y-4">
                {product.options && product.options.length > 0 && (
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-3 uppercase tracking-wider">
                      Add-ons
                    </label>
                    <div className="grid gap-3">
                      {product.options.map(opt => (
                        <label 
                          key={opt.id} 
                          className="flex items-center justify-between p-4 rounded-2xl border-2 border-slate-100 hover:border-pink-200 cursor-pointer transition-colors has-[:checked]:bg-pink-50"
                        >
                          <div className="flex items-center gap-3">
                            <input type="checkbox" className="w-5 h-5 accent-pink-500" />
                            <span className="font-semibold text-slate-800">{opt.name}</span>
                          </div>
                          <span className="font-bold" style={{ color: config.primaryColor }}>+₹{opt.price}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-4 border-t border-slate-100">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-slate-500 font-medium">Starting from</span>
                    <span className="text-3xl font-black text-slate-900">₹{product.price}</span>
                  </div>
                  <button
                    onClick={() => setStep(2)}
                    className="w-full text-white rounded-2xl py-4 font-bold text-lg hover:shadow-lg hover:opacity-90 transition-all active:scale-[0.98]"
                    style={{ backgroundColor: config.primaryColor }}
                  >
                    Select Details
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Your Details</h2>
              
              <div className="space-y-4">
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input
                    required
                    type="text"
                    placeholder="Your Name"
                    className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 outline-none"
                    style={{ '--tw-ring-color': config.primaryColor } as any}
                  />
                </div>
                
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input
                    required
                    type="tel"
                    placeholder="Phone Number"
                    className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 outline-none"
                    style={{ '--tw-ring-color': config.primaryColor } as any}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input
                      required
                      type="date"
                      className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 outline-none"
                      style={{ '--tw-ring-color': config.primaryColor } as any}
                    />
                  </div>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <select
                      className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 outline-none appearance-none"
                      style={{ '--tw-ring-color': config.primaryColor } as any}
                    >
                      <option>Morning</option>
                      <option>Afternoon</option>
                      <option>Evening</option>
                      <option>Late Night</option>
                    </select>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-slate-900 text-white rounded-2xl py-4 font-bold text-lg hover:bg-slate-800 transition-all flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  'Confirm Booking'
                )}
              </button>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="w-full text-slate-500 font-bold hover:text-slate-700 transition-colors"
              >
                Go Back
              </button>
            </form>
          )}

          {step === 3 && (
            <div className="text-center py-8">
              <div 
                className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6"
                style={{ backgroundColor: `${config.primaryColor}20`, color: config.primaryColor }}
              >
                <Sparkles size={40} />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Success!</h2>
              <p className="text-slate-500 mb-8 max-w-[280px] mx-auto">
                We've received your booking. Our team will contact you shortly to confirm the details.
              </p>
              <button
                onClick={onClose}
                className="w-full text-white rounded-2xl py-4 font-bold text-lg hover:shadow-lg hover:opacity-90 transition-all"
                style={{ backgroundColor: config.primaryColor }}
              >
                Awesome!
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
