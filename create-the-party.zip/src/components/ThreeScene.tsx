import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sphere, MeshDistortMaterial, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';

function Balloon({ position, color }: { position: [number, number, number], color: string }) {
  const mesh = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (mesh.current) {
      mesh.current.position.y += Math.sin(state.clock.elapsedTime + position[0]) * 0.002;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <mesh position={position} ref={mesh}>
        <sphereGeometry args={[0.5, 32, 32]} />
        <MeshDistortMaterial
          color={color}
          speed={3}
          distort={0.2}
          radius={1}
          metalness={0.4}
          roughness={0.4}
          transparent
          opacity={0.3}
        />
        {/* Balloon Knot/Tail */}
        <mesh position={[0, -0.6, 0]}>
          <coneGeometry args={[0.05, 0.1, 8]} />
          <meshStandardMaterial color={color} transparent opacity={0.3} />
        </mesh>
      </mesh>
    </Float>
  );
}

function Scene() {
  const balloons = useMemo(() => {
    const colors = ['#f472b6', '#3b82f6', '#fbbf24', '#ef4444', '#8b5cf6'];
    return Array.from({ length: 15 }).map((_, i) => ({
      position: [
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 5
      ] as [number, number, number],
      color: colors[i % colors.length]
    }));
  }, []);

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0, 8]} />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <spotLight position={[-10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
      
      {balloons.map((b, i) => (
        <Balloon key={i} position={b.position} color={b.color} />
      ))}
    </>
  );
}

export default function ThreeScene() {
  return (
    <div className="absolute inset-0 -z-10 bg-gradient-to-br from-indigo-50 to-pink-50 dark:from-slate-900 dark:to-slate-800">
      <Canvas>
        <Scene />
      </Canvas>
    </div>
  );
}
