import React from 'react';
import { ShoppingCart, PartyPopper, MessageCircle, Heart, Box, Package, LayoutDashboard } from 'lucide-react';
import { useConfig } from '../context/ConfigContext';
import { Link, useLocation } from 'react-router-dom';

interface NavbarProps {
  onNavigate?: (page: string) => void;
  activePage?: string;
}

export default function Navbar({ onNavigate, activePage }: NavbarProps) {
  const { config } = useConfig();
  const location = useLocation();
  const isAdminPage = location.pathname === '/admin';

  const navItems = [
    { id: 'bouquets', label: 'Bouquets', icon: PartyPopper },
    { id: 'packages', label: 'Packages', icon: Package },
    { id: 'hampers', label: 'Hampers', icon: Box },
    { id: 'combos', label: 'Combos', icon: Heart },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/70 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link 
          to="/"
          className="flex items-center gap-2 cursor-pointer" 
        >
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg transform -rotate-12"
            style={{ backgroundColor: config.primaryColor }}
          >
            {config.logoText}
          </div>
          <span className="font-display font-bold text-2xl tracking-tighter text-slate-900">
            {config.name}
          </span>
        </Link>

        {!isAdminPage && (
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate?.(item.id)}
                className="flex items-center gap-2 font-medium transition-colors"
                style={{ 
                  color: activePage === item.id ? config.primaryColor : undefined,
                }}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center gap-4">
          <Link to="/admin" className="p-2 text-slate-600 hover:text-pink-600 transition-colors">
            <LayoutDashboard size={24} />
          </Link>
          <button className="p-2 text-slate-600 hover:text-pink-600 transition-colors">
            <ShoppingCart size={24} />
          </button>
          <a 
            href={`https://wa.me/${config.contactPhone.replace(/\D/g, '')}`}
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-full font-bold shadow-lg hover:bg-green-600 transition-all scale-100 hover:scale-105"
          >
            <MessageCircle size={18} />
            <span className="hidden sm:inline">WhatsApp</span>
          </a>
        </div>
      </div>
    </nav>
  );
}
