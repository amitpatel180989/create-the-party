import React from 'react';
import { motion } from 'motion/react';
import { Product } from '../types';
import { Plus } from 'lucide-react';
import { useConfig } from '../context/ConfigContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

export default function ProductCard({ product, onSelect }: ProductCardProps) {
  const { config } = useConfig();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="group relative bg-white/40 backdrop-blur-sm rounded-3xl overflow-hidden border border-white/30 shadow-xl"
    >
      <div className="aspect-[4/5] bg-gradient-to-br from-pink-100 to-indigo-100 p-6 flex items-center justify-center relative overflow-hidden">
        {/* Animated Background Shape */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 opacity-20 pointer-events-none"
        >
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill={config.primaryColor} d="M47.7,-64.1C61.4,-57.2,71.7,-42.1,76.5,-25.6C81.3,-9,80.7,9.1,73.5,24.3C66.3,39.5,52.5,51.8,37.1,60.1C21.7,68.4,4.7,72.7,-11.1,70.2C-26.9,67.7,-41.4,58.4,-53.4,46.1C-65.4,33.8,-74.9,18.4,-77.1,2.1C-79.3,-14.2,-74.2,-31.4,-63.3,-44.6C-52.4,-57.8,-35.7,-67.1,-19.1,-70.5C-2.5,-73.9,13.9,-71.4,28.6,-66C43.3,-60.6,56.3,-52.3,47.7,-64.1Z" transform="translate(100 100)" />
          </svg>
        </motion.div>
        
        {/* Icon based on category */}
        <div className="relative z-10 flex flex-col items-center gap-4">
           {product.category === 'bouquet' && <div className="text-6xl text-pink-500">🎈</div>}
           {product.category === 'package' && <div className="text-6xl text-indigo-500">🎉</div>}
           {product.category === 'hamper' && <div className="text-6xl text-amber-500">🎁</div>}
           {product.category === 'combo' && <div className="text-6xl text-rose-500">🔥</div>}
           
           <h3 className="text-xl font-bold text-slate-800 text-center px-4 leading-tight">
             {product.name}
           </h3>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-2xl font-black" style={{ color: config.primaryColor }}>₹{product.price}</span>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {product.category}
          </span>
        </div>
        
        <p className="text-slate-500 text-sm mb-6 line-clamp-2">
          {product.description}
        </p>

        <button
          onClick={() => onSelect(product)}
          className="w-full bg-slate-900 text-white rounded-2xl py-3 font-bold transition-colors flex items-center justify-center gap-2 group/btn hover:opacity-90"
          style={{ backgroundColor: config.primaryColor }}
        >
          Book Now
          <Plus size={18} className="group-hover/btn:rotate-90 transition-transform" />
        </button>
      </div>
    </motion.div>
  );
}
