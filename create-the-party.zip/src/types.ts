export interface Product {
  id: string;
  name: string;
  category: 'bouquet' | 'package' | 'hamper' | 'combo';
  price: number;
  description: string;
  image?: string;
  options?: ProductOption[];
}

export interface ProductOption {
  id: string;
  name: string;
  price: number;
}

export interface Booking {
  id: string;
  productId: string;
  date: string;
  timeSlot: string;
  customerName: string;
  customerPhone: string;
  personalization?: {
    nameSticker?: string;
    ledLight?: boolean;
    photoPrint?: string;
    nameCard?: string;
  };
}
