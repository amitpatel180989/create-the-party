import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { motion } from 'motion/react';
import { Save, RotateCcw, Layout, Palette, Package, Type, MessageSquare, Plus, Trash2 } from 'lucide-react';
import { Product } from '../types';

export default function Admin() {
  const { config, updateConfig, resetConfig } = useConfig();
  const [activeTab, setActiveTab] = useState<'theme' | 'content' | 'products'>('theme');
  const [localConfig, setLocalConfig] = useState(config);

  const handleSave = () => {
    updateConfig(localConfig);
    alert('Configuration saved successfully!');
  };

  const handleProductChange = (id: string, field: keyof Product, value: any) => {
    const updatedProducts = localConfig.products.map(p => 
      p.id === id ? { ...p, [field]: value } : p
    );
    setLocalConfig({ ...localConfig, products: updatedProducts });
  };

  const handleSectionChange = (id: string, field: string, value: string) => {
    const updatedSections = localConfig.sections.map(s => 
      s.id === id ? { ...s, [field]: value } : s
    );
    setLocalConfig({ ...localConfig, sections: updatedSections });
  };

  const handleContactLinkChange = (id: string, field: string, value: string) => {
    const updatedLinks = (localConfig.contactLinks || []).map(l => 
      l.id === id ? { ...l, [field]: value } : l
    );
    setLocalConfig({ ...localConfig, contactLinks: updatedLinks });
  };

  const addProduct = () => {
    const newProduct: Product = {
      id: Math.random().toString(36).substr(2, 9),
      name: 'New Product',
      category: 'bouquet',
      price: 0,
      description: 'Product description',
    };
    setLocalConfig({ ...localConfig, products: [...localConfig.products, newProduct] });
  };

  const addSection = () => {
    const newSection = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Section',
      content: 'Section description...',
      icon: '✨'
    };
    setLocalConfig({ ...localConfig, sections: [...localConfig.sections, newSection] });
  };

  const addContactLink = () => {
    const newLink = {
      id: Math.random().toString(36).substr(2, 9),
      label: 'New Link',
      value: 'Value',
      url: '#',
      icon: 'instagram' as const
    };
    setLocalConfig({ ...localConfig, contactLinks: [...(localConfig.contactLinks || []), newLink] });
  };

  const removeProduct = (id: string) => {
    setLocalConfig({ ...localConfig, products: localConfig.products.filter(p => p.id !== id) });
  };

  const removeSection = (id: string) => {
    setLocalConfig({ ...localConfig, sections: localConfig.sections.filter(s => s.id !== id) });
  };

  const removeContactLink = (id: string) => {
    setLocalConfig({ ...localConfig, contactLinks: (localConfig.contactLinks || []).filter(l => l.id !== id) });
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-black text-slate-900 mb-2">Admin Dashboard</h1>
            <p className="text-slate-500">Customize every aspect of your website</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => { if(confirm('Reset all changes to default?')) resetConfig(); }}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-xl transition-colors font-bold"
            >
              <RotateCcw size={18} />
              Reset
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors shadow-lg font-bold"
            >
              <Save size={18} />
              Save Changes
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[250px_1fr] gap-8">
          {/* Sidebar Tabs */}
          <div className="flex lg:flex-col gap-2 overflow-x-auto pb-2 lg:pb-0">
            {[
              { id: 'theme', label: 'Theme & Style', icon: Palette },
              { id: 'content', label: 'Site Content', icon: Layout },
              { id: 'products', label: 'Manage Products', icon: Package },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id 
                    ? 'bg-pink-500 text-white shadow-md' 
                    : 'text-slate-600 hover:bg-white'
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Settings Panel */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-8 shadow-xl border border-slate-100"
          >
            {activeTab === 'theme' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Primary Brand Color</label>
                  <div className="flex items-center gap-4">
                    <input 
                      type="color" 
                      value={localConfig.primaryColor}
                      onChange={(e) => setLocalConfig({...localConfig, primaryColor: e.target.value})}
                      className="w-16 h-16 rounded-xl border-none cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={localConfig.primaryColor}
                      onChange={(e) => setLocalConfig({...localConfig, primaryColor: e.target.value})}
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Display Font Family</label>
                  <select 
                    value={localConfig.fontFamily}
                    onChange={(e) => setLocalConfig({...localConfig, fontFamily: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none"
                  >
                    <option value="Outfit">Outfit (Modern)</option>
                    <option value="Inter">Inter (Sans-serif)</option>
                    <option value="Space Grotesk">Space Grotesk (Tech)</option>
                    <option value="Playfair Display">Playfair Display (Elegant)</option>
                  </select>
                  <p className="text-xs text-slate-400 mt-2">Note: Font faces must be loaded in index.html</p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Logo Text</label>
                  <input 
                    type="text" 
                    value={localConfig.logoText}
                    onChange={(e) => setLocalConfig({...localConfig, logoText: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none font-black text-2xl"
                  />
                </div>
              </div>
            )}

            {activeTab === 'content' && (
              <div className="space-y-12">
                {/* Hero Settings */}
                <div className="space-y-6">
                  <h3 className="font-bold text-slate-900 border-b pb-2">Hero Section</h3>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Hero Title</label>
                    <input 
                      type="text" 
                      value={localConfig.heroTitle}
                      onChange={(e) => setLocalConfig({...localConfig, heroTitle: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Hero Subtitle</label>
                    <textarea 
                      rows={3}
                      value={localConfig.heroSubtitle}
                      onChange={(e) => setLocalConfig({...localConfig, heroSubtitle: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none resize-none"
                    />
                  </div>
                </div>

                {/* Custom Sections Settings */}
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b pb-2">
                    <h3 className="font-bold text-slate-900">Custom Columns</h3>
                    <button
                      onClick={addSection}
                      className="flex items-center gap-2 text-pink-500 hover:text-pink-600 font-bold text-sm"
                    >
                      <Plus size={16} /> Add Column
                    </button>
                  </div>
                  <div className="grid gap-4">
                    {(localConfig.sections || []).map((section) => (
                      <div key={section.id} className="p-4 border border-slate-100 rounded-2xl bg-slate-50 space-y-4 relative">
                        <button 
                          onClick={() => removeSection(section.id)}
                          className="absolute top-2 right-2 text-slate-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                        <div className="grid grid-cols-[80px_1fr] gap-4">
                          <input 
                            type="text"
                            value={section.icon}
                            onChange={(e) => handleSectionChange(section.id, 'icon', e.target.value)}
                            className="bg-white border border-slate-200 rounded-xl p-2 text-center text-xl focus:ring-2 focus:ring-pink-500 outline-none"
                            placeholder="Icon"
                          />
                          <input 
                            type="text"
                            value={section.title}
                            onChange={(e) => handleSectionChange(section.id, 'title', e.target.value)}
                            className="bg-white border border-slate-200 rounded-xl px-3 py-2 font-bold focus:ring-2 focus:ring-pink-500 outline-none"
                            placeholder="Title"
                          />
                        </div>
                        <textarea 
                          rows={2}
                          value={section.content}
                          onChange={(e) => handleSectionChange(section.id, 'content', e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none resize-none"
                          placeholder="Column content..."
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Settings */}
                <div className="space-y-6 pt-6 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">Contact & Social Links</h3>
                    <button
                      onClick={addContactLink}
                      className="flex items-center gap-2 text-pink-500 hover:text-pink-600 font-bold text-sm"
                    >
                      <Plus size={16} /> Add Link
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Primary Phone</label>
                      <input 
                        type="text" 
                        value={localConfig.contactPhone}
                        onChange={(e) => setLocalConfig({...localConfig, contactPhone: e.target.value})}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Primary Address</label>
                      <input 
                        type="text" 
                        value={localConfig.contactAddress}
                        onChange={(e) => setLocalConfig({...localConfig, contactAddress: e.target.value})}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-pink-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-4 space-y-4 border-t border-slate-50">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Additional Footer Columns</h4>
                    <div className="grid gap-4">
                      {(localConfig.contactLinks || []).map((link) => (
                      <div key={link.id} className="p-4 border border-slate-100 rounded-2xl bg-slate-50 space-y-4 relative group">
                        <button 
                          onClick={() => removeContactLink(link.id)}
                          className="absolute top-2 right-2 text-slate-300 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Label</label>
                            <input 
                              type="text"
                              value={link.label}
                              onChange={(e) => handleContactLinkChange(link.id, 'label', e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                              placeholder="e.g. Instagram"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Icon</label>
                            <select 
                              value={link.icon}
                              onChange={(e) => handleContactLinkChange(link.id, 'icon', e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                            >
                              <option value="phone">Phone</option>
                              <option value="map-pin">Address</option>
                              <option value="instagram">Instagram</option>
                              <option value="facebook">Facebook</option>
                              <option value="message-circle">WhatsApp</option>
                              <option value="mail">Email</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Display Value</label>
                            <input 
                              type="text"
                              value={link.value}
                              onChange={(e) => handleContactLinkChange(link.id, 'value', e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                              placeholder="e.g. @username"
                            />
                          </div>
                          <div className="md:col-span-3">
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">URL (Action Link)</label>
                            <input 
                              type="text"
                              value={link.url}
                              onChange={(e) => handleContactLinkChange(link.id, 'url', e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                              placeholder="https://..."
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

            {activeTab === 'products' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900">Total Products: {localConfig.products.length}</h3>
                  <button
                    onClick={addProduct}
                    className="flex items-center gap-2 bg-pink-500 text-white px-4 py-2 rounded-xl hover:bg-pink-600 transition-colors font-bold shadow-sm"
                  >
                    <Plus size={18} /> Add New
                  </button>
                </div>
                
                <div className="space-y-4">
                  {localConfig.products.map((product) => (
                    <div key={product.id} className="p-6 border border-slate-100 rounded-2xl bg-slate-50 space-y-4 relative group">
                      <button 
                        onClick={() => removeProduct(product.id)}
                        className="absolute top-4 right-4 text-slate-400 hover:text-red-500 transition-colors p-2"
                      >
                        <Trash2 size={18} />
                      </button>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Product Name</label>
                          <input 
                            type="text"
                            value={product.name}
                            onChange={(e) => handleProductChange(product.id, 'name', e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Category</label>
                          <select 
                            value={product.category}
                            onChange={(e) => handleProductChange(product.id, 'category', e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                          >
                            <option value="bouquet">Bouquet</option>
                            <option value="package">Package</option>
                            <option value="hamper">Hamper</option>
                            <option value="combo">Combo</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Price (₹)</label>
                          <input 
                            type="number"
                            value={product.price}
                            onChange={(e) => handleProductChange(product.id, 'price', Number(e.target.value))}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Description</label>
                          <input 
                            type="text"
                            value={product.description}
                            onChange={(e) => handleProductChange(product.id, 'description', e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
