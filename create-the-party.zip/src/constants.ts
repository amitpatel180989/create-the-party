import { Product } from './types';

export const PRODUCTS: Product[] = [
  // Balloon Bouquets
  {
    id: 'b1',
    name: 'Birthday Balloon Bouquet',
    category: 'bouquet',
    price: 499,
    description: 'Elegant birthday bouquet with customizable colors.',
    options: [
      { id: 'opt1', name: 'Name Sticker', price: 50 },
      { id: 'opt2', name: 'LED Light', price: 100 }
    ]
  },
  {
    id: 'b2',
    name: 'Number Balloon Bouquet',
    category: 'bouquet',
    price: 599,
    description: 'Celebrate age with giant number balloons.',
    options: [
      { id: 'opt1', name: 'Name Sticker', price: 50 },
      { id: 'opt2', name: 'LED Light', price: 100 }
    ]
  },
  {
    id: 'b3',
    name: 'Love / Anniversary Bouquet',
    category: 'bouquet',
    price: 699,
    description: 'Romantic heart-shaped balloons for your special someone.',
  },
  {
    id: 'b4',
    name: 'Kids Cartoon Bouquet',
    category: 'bouquet',
    price: 799,
    description: 'Featuring their favorite characters!',
  },

  // Decoration Packages
  {
    id: 'p1',
    name: 'Basic Room Decoration',
    category: 'package',
    price: 999,
    description: 'Perfect for small surprises at home.',
  },
  {
    id: 'p2',
    name: 'Standard Decoration',
    category: 'package',
    price: 1999,
    description: 'Balloon arch, wall decor, and foil balloons included.',
  },
  {
    id: 'p3',
    name: 'Premium Decoration',
    category: 'package',
    price: 3999,
    description: 'Luxury setup with cake table and full room makeover.',
  },

  // Gift Hampers
  {
    id: 'h1',
    name: 'Chocolate + Balloon Hamper',
    category: 'hamper',
    price: 899,
    description: 'Sweet surprises delivered in a box.',
  },
  {
    id: 'h2',
    name: 'Teddy + Balloon Hamper',
    category: 'hamper',
    price: 1299,
    description: 'Cuddly teddy paired with festive balloons.',
  },
  {
    id: 'h3',
    name: 'Romantic Hamper',
    category: 'hamper',
    price: 1499,
    description: 'Roses, lights, and balloons for a romantic night.',
  },

  // Combos
  {
    id: 'c1',
    name: 'Balloon Bouquet + Gift Hamper',
    category: 'combo',
    price: 1499,
    description: 'Best of both worlds: a bouquet and a hamper.',
  },
  {
    id: 'c2',
    name: 'Decoration + Cake + Bouquet',
    category: 'combo',
    price: 2999,
    description: 'The ultimate party celebration package.',
  }
];
